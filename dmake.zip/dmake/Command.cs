﻿// (c) 2018 by Tom van Dijkhuizen. All rights reserved.

// .NET namespaces
using System;
using System.Text;
using System.Xml.Linq;
using System.Collections.Generic;

// Other namespaces
using UOSS;

// Typedefs
using i32 = System.Int32;

namespace dmake {
	// OBject that contains IDs of Command objects (i.e. dependencies) and command lines.
	public class Command : Node {
		public const String PublicTypeName = "command";
		private readonly List<String> m_Dependencies = new List<String>();
		
		public i32 CommandCount => this.RunIdx < 0 ? 0 : this.Children[this.RunIdx].Children.Count;
		public i32 DependencyCount => this.DepIdx < 0 ? 0 : this.Children[this.DepIdx].Children.Count;

		// Index of node in this.Children to find Run objects.
		private i32 RunIdx = -1;
		// Index of node in this.Children to find dependencies.
		private i32 DepIdx = -1;

		private static bool TypeRegistered = false;
		internal static void RegisterType() {
			PsiHelperNode.RegisterType();
			Array<PsiHelperNode>.RegisterType();
			if(Command.TypeRegistered) return;

			TreeBuilder.RegisterType(typeof(Command),Command.PublicTypeName,(XElement el,Node Parent,Document owner) => {
				IEnumerable<XElement> Children = el.Elements();
				var ret = new Command(el.Name.ToString(),Parent,owner);
				foreach(XElement c in Children) {
					String Name = c.Name.ToString();
					if(Name.Equals("dependencies")) {
						ret.DepIdx = ret.Children.Count;
						ret.Children.Add(TreeBuilder.InvokeParser(c,Parent,owner));
					} else if(Name.Equals("run")) {
						ret.RunIdx = ret.Children.Count;
						ret.Children.Add(TreeBuilder.InvokeParser(c,Parent,owner));
					} // if
				} // foreach
				return ret;
			},(Node N,i32 lvl) => {
				TreeBuilder.CheckChildCount(N,0,0);
				return ((Command) N).ToXML_internal(lvl);
			});

			Command.TypeRegistered = true;
		}

		private String ToXML_internal(i32 lvl) {
			var sb = new StringBuilder();
			String T1 = TreeBuilder.GenerateTabs(lvl);
			String T2 = TreeBuilder.GenerateTabs(lvl + 1);
			sb.AppendFormat("{0}<{1} type=\"{2}\">",T1,this.Name,this.TypeName).AppendLine();

			//sb.AppendFormat("{1}{1}",T2,(TreeBuilder.BuildTree("dependencies",this.Dependencies)).ToXML(lvl + 1));
			//sb.AppendFormat("{1}{1}",T2,(TreeBuilder.BuildTree("run",this.Run)).ToXML(lvl + 1));

			//sb.AppendFormat("{0}<run type=\"array.ProcessStartInfo\" format=\"ArrayElement{{0}}\">",T1);
			foreach(Node nd in this.Children) sb.AppendLine(TreeBuilder.GenerateNodeXML(lvl + 1,nd));
			//sb.AppendFormat("{0}</run>",T1);

			sb.AppendFormat("{0}</{1}>",T1,this.Name).AppendLine();

			return sb.ToString();
		}
		
		public PsiHelperNode GetPsiHelper(i32 idx) => (PsiHelperNode) this.Children[this.RunIdx].Children[idx];
		public String GetDependency(i32 idx) => (String) this.Children[this.DepIdx].Children[idx].Value;
		
		public Command(String Name,Node Parent,Document owner) : base(Name,Command.PublicTypeName,typeof(Command),null,Parent,owner) {
		}
	}
}
